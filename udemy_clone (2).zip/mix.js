function logolink() {
  window.location.href = "index.html";
}
function cartPage() {
  window.location.href = "cart.html";
}

function loginPage() {
  window.location.href = "login.html";
}

function signupPage() {
  window.location.href = "signup.html";
}

function exploreCourses() {
  window.location.href = "categories.html";
}

function singleProduct() {
  window.location.href = "product.html";
}
